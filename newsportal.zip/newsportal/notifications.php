<?php

	$errors = array();
	$success = array();
?>