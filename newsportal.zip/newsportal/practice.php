<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/practice.css">
	<title></title>
</head>
<body>

<header>
	<div class="header-top">
		<div class="container">
			<div class="row">
				<div class="col-30">
					<div class="logo">
						<a href="#"><img src="img/logo.png" class="responsive-image"></a>
					</div>
				</div>
				<div class="col-70">
			<!--		<a href="#"><img src="img/ad-image.jp" class="responsive-image"></a>-->
				</div>
			</div>
		</div>
	</div>
	<nav>
		<div class="container">
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">Bangladesh</a></li>
				<li><a href="#">International</a></li>
				<li><a href="#">Sports</a></li>
				<li><a href="#">Teachnology</a></li>
				<li><a href="#">Opinion</a></li>
				<li><a href="#">Others</a></li>
			</ul>
		</div>
	</nav>

	<div class="breaking-news">
		<div class="container">
			<div class="row">
				<div class="col-20">
					<div class="update-left">
						Update
					</div>
				</div>
				<div class="col-80">
					<div class="update-right">
						<marquee> This web is buit for learning purpose. It built by using html css php java script.</marquee>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>

</body>
</html>