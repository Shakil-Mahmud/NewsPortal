	<nav>
		<div class="">
			<div class="">
				<ul id="">
					<li class=""><a href="#">Bangladesh</a></li>
					<li class=""><a href="#">International</a></li>
					<li class=""><a href="#">Sports</a></li>
					<li class=""><a href="#">Technology</a></li>
					<li class=""><a href="#">Business</a></li>
					<li class=""><a href="#">Opinion</a></li>
				</ul>
			</div>
		</div>			
	</nav>