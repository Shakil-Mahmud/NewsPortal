<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "newsportal1";
$conn = mysqli_connect($servername, $username ,$password, $dbname) or 
die("connection error : ".mysqli_connect_error());
?>